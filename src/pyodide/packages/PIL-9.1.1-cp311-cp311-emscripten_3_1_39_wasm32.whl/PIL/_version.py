# Master version for Pillow
__version__ = "9.1.1"
